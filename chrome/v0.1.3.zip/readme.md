# Kallax Chrome Extension

## An extension to integrate Kallax.io with the web 

### Features:
* Indicator on BGG and BGA sites to 
  * Quick add to Kallax.io collection
  * Show whether each game is owned by you and/or a friend
  * Add/remove a game from your Kallax.io collection
  * Navigate to kallax.io

_note: this extension is not an official project of kallax.io_
